import React from 'react'

const NoMatch = ({ location }) => (
  <h1>Page not found {location.pathname}</h1>
)

export default NoMatch
